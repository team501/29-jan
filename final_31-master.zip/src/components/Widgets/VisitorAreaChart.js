/**
 * Visitor Area Chart Widget
 */
import React from 'react';
import CountUp from 'react-countup';

// chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';

// intl messages
import IntlMessages from 'Util/IntlMessages';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard';

// chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';

// Circular Progress Bar
import CircularProgressbar from 'react-circular-progressbar';

const VisitorAreaChart = ({ data }) => (
    <RctCard>
        <RctCardContent>
            <div className="clearfix">
                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
                    <h3 className="mb-15 fw-semi-bold">Inducts for the Day {/*<IntlMessages id="widgets.visitors" />*/}</h3>
                    <div className="d-flex">
                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
                            {/* Circular Guage */}
                            <CircularProgressbar
                                percentage={70}
                                text={`${70}%`}
                                backgroundPadding={0}
                                styles={{
                                    path: { stroke: `rgba(135,0,56, ${70 / 100})`, strokeLinecap: 'butt' },
                                    text: { fill: '#121212', fontSize: '25px'},
                                    trail: { stroke: '#d7d7d7' },
                                    background: {
                                        fill: '#ffffff'
                                    }
                                }}
                            />
                             <span className="counter-point"> 70% </span>
                        </div>
                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
                                <span className="counter-point">
                                    3000 / 20000
                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
                                </span>
                            </div>
                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
                                <TinyAreaChart
                                    label="Last 5 Days"
                                    chartdata={data.chartData.data}
                                    labels={data.chartData.labels}
                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
                                    borderColor={hexToRgbA(ChartConfig.color.primary, 3)}
                                    lineTension="0"
                                    height={90}
                                    gradient
                                    
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </RctCardContent>
    </RctCard >
);

export default VisitorAreaChart;
