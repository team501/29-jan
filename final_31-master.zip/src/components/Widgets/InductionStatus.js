/**
 * InductsForTheDay
 */
import React, { Component } from 'react';
//axios
import axios from 'axios';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';

//circular-progressbar
import CircularProgressbar from 'react-circular-progressbar';

//bar chart
import {Bar} from 'react-chartjs-2';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

class InductionStatus extends Component {
	constructor(props) {
		super(props);
		this.state = {  label: [],
						graphData: [],
					    isLoading:true
					  };
	}
	
	async componentWillMount() {
		axios.get(baseURL+'inductionstatusperhour/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    let label = new Array();
			    label.push("Peak");
			    label.push("Average");
			    label.push("Recric");
			    label.push("Minimum");
			    
			    let graphData = new Array();
			    graphData.push(res.data.peak);
			    graphData.push(res.data.average);
			    graphData.push(res.data.recric);
			    graphData.push(res.data.minimum);
			    
			    console.log("INDSPHR");
			    console.log(graphData);
			    console.log(label);
		        this.setState({ label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}
	
	defaultLabel = this.props.label === undefined ? ['1', '2', '3', '4', '5'] : this.props.label;
	defaultData =  this.props.graphData === undefined ? [10, 15, 25, 15, 40] : this.props.graphData;
	findMinimum =  Math.min(...this.defaultData) - (1);
	
	data = { labels: this.defaultLabel,
			datasets: [ { 
				backgroundColor: [
					'rgba(245, 166, 35)',
					'rgba(126, 211, 33)',
					'rgba(248, 231, 28)',
					'rgba(208, 2, 27)'

					],
					borderColor: [
						'rgba(245, 166, 35)',
						'rgba(126, 211, 33)',
						'rgba(248, 231, 28)',
						'rgba(208, 2, 27)'

						],		  			
						borderWidth: 1,
						hoverBackgroundColor: 'rgba(255,99,132,0.4)',
						hoverBorderColor: 'rgba(255,99,132,1)',
						data: [ ...this.defaultData, this.findMinimum]
			}]
	};
	
	render() { 
	 return (
			<div className="row">

				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Induction status per hour"}
				reloadable
				fullBlock
				>
                <div className="col-md-10 col-xl-10 col-sm-10 col-ls-10 float-left">  
								<Bar data={this.data} width={20} height={250} options={{ maintainAspectRatio: false, legend: {
									display: false
								},scales: {
									xAxes: [{
										barPercentage: 0.1,
										ticks: {
											fontSize: 20
										},
										gridLines : {
											                display : false
											            } 
									}],
									yAxes: [{
										position: 'right',
										ticks: {
											fontSize: 20,
											fontWeight:800
										}
									}]}  }}/> 
						
							
				</div>
				<div class="right-arrow_induct"><i class="ti-angle-right"></i></div>

					</RctCollapsibleCard>
					</div>
				);
		}
}

export default InductionStatus;
