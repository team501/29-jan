/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import Grid from '@material-ui/core/Grid';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
import { ProgressBar, Label } from 'react-bootstrap';


class WaveStatus extends Component {

	state = {
			data: [],
			label: null,
			graphData: null
	}

	componentDidMount() {
		this.getRecentOrders();
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'wavestatustoday/'+ sessionStorage.getItem("username") )
		 .then(res => {
			    console.log(res);
		        this.setState({ allocated: res.data.allocated,
								id: res.data.id,
								remaining: res.data.remaining,
								sorted: res.data.sorted,
								units: res.data.units,
								userid: res.data.userid,
								wave: res.data.wave,
								allocatedPercentage: res.data.allocatedPercentage,
								sortedPercentage: res.data.sortedPercentage,
								remainingPercentage: res.data.remainingPercentage,
					        	isLoading:false});
		}).catch(function (error) {
		    console.log(error);
		  });
	}

	render() {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={"Wave Status Wave: " + this.state.wave + " Units:" + this.state.units}
					reloadable
					fullBlock
				>
				<div className="progressbar-gap">
	                    <ProgressBar>
	                  		<ProgressBar bsStyle="success" now={this.state.allocatedPercentage} key={1} />
	                  		<ProgressBar bsStyle="warning" now={this.state.sortedPercentage} key={2} />
	                  		<ProgressBar bsStyle="danger" now={this.state.remainingPercentage} key={3} />
	                  	</ProgressBar>
						</div>
	                  		
                  		<Grid style={{textAlign: 'center'}}container>
							<Grid item xs={4} sm={4}>
								<Label bsStyle="success">Allocated</Label>{' '}
								<Grid item xs={12} sm={12}>
									({this.state.allocated})
								</Grid>
							</Grid>
							<Grid item xs={4} sm={4}>
								<Label bsStyle="warning">Sorted</Label>{' '}
								<Grid item xs={12} sm={12}>
									({this.state.sorted})
								</Grid>
							</Grid>
							<Grid item xs={4} sm={4}>
								<Label bsStyle="danger">Remaining</Label>
								<Grid item xs={12} sm={12}>
									({this.state.remaining})
								</Grid>
							</Grid>
						</Grid>
            </RctCollapsibleCard>
		);
	}
}

export default WaveStatus;
