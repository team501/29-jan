import React, { Component } from 'react';
import {BrowserRouter, Route, Redirect, Switch, Link} from 'react-router-dom';
import './landing.css';
import IntlMessages from 'Util/IntlMessages';
import Dashboard from '../../assets/img/dashboard.jpg';
import Manage from '../../assets/img/manage.jpg';
import Labour from '../../assets/img/labour.jpg';
import ManageEqe from '../../assets/img/manage_eqe.jpg';
import Workmonotring from '../../assets/img/work-monotring.jpg';
import ManageInvontry from '../../assets/img/manage-invontry.jpg';
import Exception from '../../assets/img/exceptions.jpg';
import Report from '../../assets/img/report.jpg';
import Footer from './Footer';

class Main extends React.Component {
    render(){
      return(
		<div className="main-bg">
				<div className="main-content">
					<ul>
						<li><div className="main-content-img"><img src={Dashboard}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.dashboard" /></div>
						</li>
						
						<li><div className="main-content-img"><img src={Manage}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.ManageOrderWaves" /></div>
						</li>
					
						<li><div className="main-content-img"><img src={Labour}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.BalanceLabour" /></div>
						</li>
					
						<li><div className="main-content-img"><img src={ManageEqe}/></div>
						
						<div className="main-content-text"><Link to={`/app/dashboard/manageEquipment`} activeClassName="active"><IntlMessages id="widgets.ManageEquipment" /></Link></div>
						</li>
					
						<div className="clear-both"></div>
						<li><div className="main-content-img"><img src={Workmonotring}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.WorkMonitoring" /></div>
						</li>
						
						<li><div className="main-content-img"><img src={ManageInvontry}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.ManageInventory" /></div>
						</li>
					
						<li><div className="main-content-img"><img src={Exception}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.Exceptions" /></div>
						</li>
					
						<li><div className="main-content-img"><img src={Report}/></div>
						<div className="main-content-text"><IntlMessages id="widgets.Report" /></div>
						</li>
					</ul>
				</div>
		</div>
      );
    }
  }
export default Main;
